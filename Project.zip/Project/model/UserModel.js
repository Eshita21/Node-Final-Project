const mongoose=require('mongoose');
const UserModel= mongoose.Schema;


const Data= new UserModel({
username:{
type:String,
required:true
},
email:{
type:String,
required:true
},
phone:{
    type:Number,
    required:true
},
password:{
    type:String,
    required:true
},
status:{
    type:Number,
    default:1
}
})
const UserData= mongoose.model("project_data",Data)
module.exports=UserData;
