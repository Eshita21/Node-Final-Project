const mongoose=require('mongoose');
const PostModel = mongoose.Schema

const Data= new PostModel({
title:{
type:String,
required:true
},
subtitle:{
type:String,
required:true
},
post:{
type:String,
required:true
},
image:{
type:String,
required:true
}
})
const PostData= mongoose.model("PostData",Data)
module.exports = PostData