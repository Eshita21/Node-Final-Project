const AdminModel=require('../model/UserModel')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

exports.login=(req,res) => {
    res.render('adminlogin',{
    message:req.flash('message')
    })
}

exports.signin=(req,res)=>{
    AdminModel.findOne({
    email:req.body.email
    },(err,data)=>{
    if(data){
    if(data.status){
    if(data.isAdmin=="admin"){
        const hashPassword = data.password;
        if(bcrypt.compareSync(req.body.password , hashPassword)){
               const token = jwt.sign({
                     id: data._id,
                    username: data.username,
                    email: data.email}, 
            "eshitaadmin-23051998@#1!4959", { expiresIn: '20m' })
            res.cookie("adminToken", token);    
            res.redirect("adminDashbord")
        }
        else {
            req.flash('massage',"Password Not Match!")

               console.log("Password Not Match!");
               res.redirect('/admin/admin')
        }
    } else{
        req.flash('massage',"You are not Admin!")

        console.log("You are not Admin!");
        res.redirect('/admin/admin')
    }
    }
    else {
        req.flash('massage',"Email Not Exist!")

        console.log('Email Not Exist!');
        res.redirect('/admin/admin')
    }
    }
})
}

exports.adminAuth = (req, res, next) => {
    if (req.admin) {
        console.log(req.admin);
        next();
    } else {
        console.log('Error while Admin Auth');
        res.redirect('/admin/admin')
    }
}
exports.adminDeshbord = (req, res) => {
    res.render('admindash', {
        adminData: req.admin
    })
}


