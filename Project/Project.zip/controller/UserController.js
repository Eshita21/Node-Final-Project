const UserModel=require('../model/UserModel')
const PostData = require('../model/PostModel')

exports.home=(req,res) =>{
PostData.find((err,data)=>{
// console.log("Its my data :)",data);
if(!err){
    res.render('home',{
        data:req.user,
        displayData:data
        
    })
}  
})
}

exports.about=(req,res) =>{
res.render('about',{
data:req.user
})
}

exports.contact=(req,res) =>{
res.render('contact',{
data:req.user
})
}

exports.index_login=(req,res)=>{
loginData={}
loginData.email=(req.cookies.email) ? req.cookies.email : undefined
loginData.password=(req.cookies.password) ? req.cookies.password : undefined
res.render('login',{
message: req.flash("message"),
data:loginData
})
}

exports.register_page=(req,res)=>{
res.render('register',{
message: req.flash("message")
})
}

exports.userAuth=(req,res,next)=>{
if(req.user){
console.log(req.user)
next()
}
else{
console.log(req.user)
res.redirect('/index_login')
}
}

exports.dashboard=(req,res)=>{
if(req.user){
UserModel.find({}, (err,details)=>{
if(!err){
res.render('dashboard',{
data:req.user,
userDetails: details
})
}
else {
console.log(err);
}
})
}
}


exports.post=(req,res)=>{
    res.render('create_post',{
    data:req.user
    })
}
 
exports.post_data=(req,res)=>{
    const image = req.file
    const NewData= new PostData({
    title:req.body.title,
    subtitle:req.body.subtitle,
    post:req.body.editor1,
    image:image.path
})
NewData.save().then((result)=>{
    console.log("Post Added Successfully!")
    res.redirect("/")
}).catch((err)=>{
console.log(err)
})
}

exports.logout = (req, res) => {
    res.clearCookie("UserToken");
    res.redirect("/");
}
