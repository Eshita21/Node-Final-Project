const express = require('express');
const route = express.Router()
const controller = require('../controller/AdminController')

route.get('/admin', controller.login)
route.get('/adminDashbord', controller.adminAuth, controller.adminDeshbord)
route.post('/adminlogin', controller.signin)


module.exports = route;